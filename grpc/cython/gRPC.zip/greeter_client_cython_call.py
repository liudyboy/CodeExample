from PyGreeterClient import PyGreeterClient as greeter
g = greeter("localhost:50051")
print(g.SayHello("cython"))
